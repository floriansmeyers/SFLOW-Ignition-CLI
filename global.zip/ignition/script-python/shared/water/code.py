def getSimulationData(seconds=0):
	seconds = seconds % 86400
	return system.db.runNamedQuery("OnlineDemo", "Simulation_Data/water", {"seconds":seconds})
	