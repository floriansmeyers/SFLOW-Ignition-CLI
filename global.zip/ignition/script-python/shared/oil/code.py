def getSimulationData():
	currentTime = system.date.now()
	seconds = system.date.secondsBetween(system.date.midnight(currentTime), currentTime)
	weekday = currentTime.getDay()

	seconds = seconds % 86400
	weekday = weekday % 7
	return system.db.runNamedQuery("OnlineDemo", "Simulation_Data/oil", {"second":seconds, "weekday":weekday})