def doPost(request, session):
	import json
	try:
		body = request["data"]
		# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
		if isinstance(body, (str, unicode)):
			data = json.loads(body)
		elif isinstance(body, dict):
			data = body
		else:
			try:
				data = json.loads(system.util.jsonEncode(body))
			except Exception:
				return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
		action = data.get("action", "get")
		from com.inductiveautomation.ignition.gateway import IgnitionGateway
		gw = IgnitionGateway.get()
		sm = gw.getSystemManager()
		if action == "get":
			import java.util.TimeZone as TimeZone
			tz = TimeZone.getDefault()
			return {"json": json.dumps({
				"timezone": tz.getID(),
				"displayName": tz.getDisplayName(),
				"rawOffset": tz.getRawOffset(),
			})}
		elif action == "set_timezone":
			tz_id = data.get("timezone", "")
			if not tz_id:
				return {"json": json.dumps({"error": "No timezone provided"})}
			import java.util.TimeZone as TimeZone
			available = list(TimeZone.getAvailableIDs())
			if tz_id not in available:
				return {"json": json.dumps({"error": "Invalid timezone: " + tz_id, "hint": "Use a valid IANA timezone ID (e.g. Europe/Brussels, America/New_York)"})}
			TimeZone.setDefault(TimeZone.getTimeZone(tz_id))
			return {"json": json.dumps({"timezone": tz_id, "message": "Gateway timezone set to " + tz_id})}
		elif action == "list_timezones":
			import java.util.TimeZone as TimeZone
			region = data.get("region", "")
			ids = sorted(list(TimeZone.getAvailableIDs()))
			if region:
				ids = [tz for tz in ids if tz.lower().startswith(region.lower())]
			return {"json": json.dumps({"timezones": ids, "count": len(ids)})}
		else:
			return {"json": json.dumps({"error": "Unknown action: " + action + ". Use get, set_timezone, or list_timezones."})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
