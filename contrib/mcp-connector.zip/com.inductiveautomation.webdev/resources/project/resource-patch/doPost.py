def doPost(request, session):
	import json
	import os
	try:
		body = request["data"]
		# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
		if isinstance(body, (str, unicode)):
			data = json.loads(body)
		elif isinstance(body, dict):
			data = body
		else:
			# Java Map/List — use Ignition's native JSON encoder which handles Java types
			try:
				data = json.loads(system.util.jsonEncode(body))
			except Exception:
				return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
		project = data.get("project", "")
		resource_path = data.get("resource_path", "")
		patches = data.get("patches", [])
		if not project or not resource_path:
			return {"json": json.dumps({"error": "Both project and resource_path are required"})}
		if not patches or not isinstance(patches, list):
			return {"json": json.dumps({"error": "patches must be a non-empty list of {path, value} objects"})}
		# Discover data directory via IgnitionGateway
		from com.inductiveautomation.ignition.gateway import IgnitionGateway
		gw = IgnitionGateway.get()
		data_dir = str(gw.getSystemManager().getDataDir())
		projects_dir = os.path.join(data_dir, "projects")
		# Build and validate path
		target = os.path.realpath(os.path.join(projects_dir, project, resource_path))
		if not target.startswith(os.path.realpath(projects_dir) + os.sep):
			return {"json": json.dumps({"error": "Path traversal blocked"})}
		if not os.path.isfile(target):
			return {"json": json.dumps({"error": "File not found: " + resource_path})}
		# Read and parse JSON
		with open(target, "r") as f:
			doc = json.loads(f.read())
		# Validate all patch paths before writing (atomic: all-or-nothing)
		results = []
		for patch in patches:
			path_str = patch.get("path", "")
			if not path_str:
				return {"json": json.dumps({"error": "Each patch must have a non-empty 'path'"})}
			if "value" not in patch:
				return {"json": json.dumps({"error": "Each patch must have a 'value' field"})}
			segments = path_str.split(".")
			# Navigate to target — greedy matching for dotted keys
			node = doc
			pos = 0
			while pos < len(segments):
				remaining = len(segments) - pos
				if isinstance(node, list):
					seg = segments[pos]
					try:
						idx = int(seg)
					except ValueError:
						return {"json": json.dumps({"error": "Invalid path: '" + path_str + "' — segment '" + seg + "' is not a valid array index"})}
					if idx < 0 or idx >= len(node):
						return {"json": json.dumps({"error": "Invalid path: '" + path_str + "' — index " + seg + " out of range"})}
					if remaining == 1:
						old_val = node[idx]
						results.append({"path": path_str, "old_value": old_val, "new_value": patch["value"], "node": node, "key": seg})
						break
					node = node[idx]
					pos += 1
				elif isinstance(node, dict):
					matched = False
					for length in range(1, remaining + 1):
						candidate = ".".join(segments[pos:pos + length])
						if candidate in node:
							if pos + length == len(segments):
								old_val = node[candidate]
								results.append({"path": path_str, "old_value": old_val, "new_value": patch["value"], "node": node, "key": candidate})
							else:
								node = node[candidate]
							pos += length
							matched = True
							break
					if not matched:
						return {"json": json.dumps({"error": "Invalid path: '" + path_str + "' — key '" + segments[pos] + "' not found"})}
				else:
					return {"json": json.dumps({"error": "Invalid path: '" + path_str + "' — cannot traverse into " + type(node).__name__})}
		# All paths validated — apply patches
		for r in results:
			node = r["node"]
			key = r["key"]
			if isinstance(node, list):
				node[int(key)] = r["new_value"]
			else:
				node[key] = r["new_value"]
		# Write back
		with open(target, "w") as f:
			f.write(json.dumps(doc, indent=2))
		system.project.requestScan()
		# Clean up internal keys from results
		clean = [{"path": r["path"], "old_value": r["old_value"], "new_value": r["new_value"]} for r in results]
		return {"json": json.dumps({"project": project, "resource_path": resource_path, "patches_applied": len(clean), "details": clean, "message": "Patches applied and project scan requested."})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
