def doPost(request, session):
\timport json
\timport os
\ttry:
\t\tbody = request["data"]
\t\t# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
\t\tif isinstance(body, (str, unicode)):
\t\t\tdata = json.loads(body)
\t\telif isinstance(body, dict):
\t\t\tdata = body
\t\telse:
\t\t\t# Java Map/List — use Ignition's native JSON encoder which handles Java types
\t\t\ttry:
\t\t\t\tdata = json.loads(system.util.jsonEncode(body))
\t\t\texcept Exception:
\t\t\t\treturn {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
\t\tproject = data.get("project", "")
\t\tresource_path = data.get("resource_path", "")
\t\tmax_files = int(data.get("max_files", 500))
\t\tif not project or not resource_path:
\t\t\treturn {"json": json.dumps({"error": "Both project and resource_path are required"})}
\t\t# Discover data directory via IgnitionGateway
\t\tfrom com.inductiveautomation.ignition.gateway import IgnitionGateway
\t\tgw = IgnitionGateway.get()
\t\tdata_dir = str(gw.getSystemManager().getDataDir())
\t\tprojects_dir = os.path.join(data_dir, "projects")
\t\t# Build and validate path
\t\ttarget = os.path.realpath(os.path.join(projects_dir, project, resource_path))
\t\tif not target.startswith(os.path.realpath(projects_dir) + os.sep):
\t\t\treturn {"json": json.dumps({"error": "Path traversal blocked"})}
\t\tif os.path.isfile(target):
\t\t\t# Try text mode first; fall back to named query extraction for data.bin
\t\t\ttry:
\t\t\t\twith open(target, "r") as f:
\t\t\t\t\tcontent = f.read()
\t\t\t\treturn {"json": json.dumps({"type": "file", "project": project, "resource_path": resource_path, "content": content, "size": len(content)})}
\t\t\texcept:
\t\t\t\t# Binary file — check if it's a named query data.bin
\t\t\t\tif resource_path.endswith("/data.bin") and "/named-query/" in resource_path:
\t\t\t\t\ttry:
\t\t\t\t\t\t# Extract query path from resource_path: ignition/named-query/Folder/Name/data.bin
\t\t\t\t\t\tparts = resource_path.split("/named-query/", 1)
\t\t\t\t\t\tif len(parts) == 2:
\t\t\t\t\t\t\tquery_path = parts[1].rsplit("/data.bin", 1)[0]
\t\t\t\t\t\t\tnqm = gw.getNamedQueryManager()
\t\t\t\t\t\t\tnq = nqm.getQueryFromPath(project, query_path)
\t\t\t\t\t\t\tparams = []
\t\t\t\t\t\t\tfor p in nq.getParameters():
\t\t\t\t\t\t\t\tparams.append({"name": str(p.getIdentifier()), "type": str(p.getType())})
\t\t\t\t\t\t\tresult = {
\t\t\t\t\t\t\t\t"type": "named_query",
\t\t\t\t\t\t\t\t"project": project,
\t\t\t\t\t\t\t\t"resource_path": resource_path,
\t\t\t\t\t\t\t\t"query_path": query_path,
\t\t\t\t\t\t\t\t"query": str(nq.getQuery()),
\t\t\t\t\t\t\t\t"database": str(nq.getDatabase()),
\t\t\t\t\t\t\t\t"query_type": str(nq.getType()),
\t\t\t\t\t\t\t\t"parameters": params,
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\treturn {"json": json.dumps(result)}
\t\t\t\t\texcept:
\t\t\t\t\t\tpass
\t\t\t\t# Generic binary — return base64
\t\t\t\timport base64
\t\t\t\twith open(target, "rb") as f:
\t\t\t\t\traw = f.read()
\t\t\t\treturn {"json": json.dumps({"type": "binary", "project": project, "resource_path": resource_path, "content_base64": base64.b64encode(raw).decode("ascii"), "size": len(raw)})}
\t\tif os.path.isdir(target):
\t\t\tfiles = []
\t\t\ttruncated = False
\t\t\tfor root, dirs, fnames in os.walk(target):
\t\t\t\tdirs.sort()
\t\t\t\tfor fn in sorted(fnames):
\t\t\t\t\tif len(files) >= max_files:
\t\t\t\t\t\ttruncated = True
\t\t\t\t\t\tbreak
\t\t\t\t\tfull = os.path.join(root, fn)
\t\t\t\t\trel = full[len(target):].lstrip(os.sep).replace("\\", "/")
\t\t\t\t\tfiles.append(rel)
\t\t\t\tif truncated:
\t\t\t\t\tbreak
\t\t\treturn {"json": json.dumps({"type": "directory", "project": project, "resource_path": resource_path, "files": files, "count": len(files), "truncated": truncated})}
\t\treturn {"json": json.dumps({"error": "Not found: " + resource_path})}
\texcept:
\t\timport sys
\t\treturn {"json": json.dumps({"error": str(sys.exc_info()[1])})}
