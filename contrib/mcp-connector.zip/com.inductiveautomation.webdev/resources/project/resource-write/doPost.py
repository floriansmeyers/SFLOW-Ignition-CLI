def doPost(request, session):
\timport json
\timport os
\ttry:
\t\tbody = request["data"]
\t\t# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
\t\tif isinstance(body, (str, unicode)):
\t\t\tdata = json.loads(body)
\t\telif isinstance(body, dict):
\t\t\tdata = body
\t\telse:
\t\t\t# Java Map/List — use Ignition's native JSON encoder which handles Java types
\t\t\ttry:
\t\t\t\tdata = json.loads(system.util.jsonEncode(body))
\t\t\texcept Exception:
\t\t\t\treturn {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
\t\tproject = data.get("project", "")
\t\tresource_path = data.get("resource_path", "")
\t\tcontent = data.get("content", "")
\t\tif not project or not resource_path:
\t\t\treturn {"json": json.dumps({"error": "Both project and resource_path are required"})}
\t\tif content is None:
\t\t\treturn {"json": json.dumps({"error": "content is required"})}
\t\t# Discover data directory via IgnitionGateway
\t\tfrom com.inductiveautomation.ignition.gateway import IgnitionGateway
\t\tgw = IgnitionGateway.get()
\t\tdata_dir = str(gw.getSystemManager().getDataDir())
\t\tprojects_dir = os.path.join(data_dir, "projects")
\t\t# Build and validate path
\t\ttarget = os.path.realpath(os.path.join(projects_dir, project, resource_path))
\t\tif not target.startswith(os.path.realpath(projects_dir) + os.sep):
\t\t\treturn {"json": json.dumps({"error": "Path traversal blocked"})}
\t\tif not os.path.isfile(target):
\t\t\treturn {"json": json.dumps({"error": "File not found: " + resource_path + ". Use import_project_resource to create new resources."})}
\t\twith open(target, "w") as f:
\t\t\tf.write(content)
\t\t# Trigger project scan so changes take effect immediately
\t\tsystem.project.requestScan()
\t\treturn {"json": json.dumps({"project": project, "resource_path": resource_path, "written": len(content), "message": "File updated and project scan requested."})}
\texcept:
\t\timport sys
\t\treturn {"json": json.dumps({"error": str(sys.exc_info()[1])})}
