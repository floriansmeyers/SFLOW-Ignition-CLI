def doPost(request, session):
\timport json
\timport traceback
\ttry:
\t\tbody = request["data"]
\t\t# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
\t\tif isinstance(body, (str, unicode)):
\t\t	data = json.loads(body)
\t\telif isinstance(body, dict):
\t\t	data = body
\t\telse:
\t\t	try:
\t\t		data = json.loads(system.util.jsonEncode(body))
\t\t	except Exception:
\t\t		return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
\t\tdatabase = data.get("database", "")
\t\taction = data.get("action", "list_tables")
\t\tif not database:
\t\t\treturn {"json": json.dumps({"error": "No database specified"})}
\t\tif action == "list_tables":
\t\t\ttry:
\t\t\t\tquery = "SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME"
\t\t\t\tdataset = system.db.runQuery(query, database)
\t\t\t\ttables = []
\t\t\t\tfor row in range(dataset.getRowCount()):
\t\t\t\t\ttables.append({"name": str(dataset.getValueAt(row, 0)), "type": str(dataset.getValueAt(row, 1))})
\t\t\t\treturn {"json": json.dumps({"tables": tables, "count": len(tables)})}
\t\t\texcept:
\t\t\t\tquery = "SELECT name, type FROM sqlite_master WHERE type IN ('table', 'view') ORDER BY name"
\t\t\t\tdataset = system.db.runQuery(query, database)
\t\t\t\ttables = []
\t\t\t\tfor row in range(dataset.getRowCount()):
\t\t\t\t\ttables.append({"name": str(dataset.getValueAt(row, 0)), "type": str(dataset.getValueAt(row, 1)).upper() + " TABLE"})
\t\t\t\treturn {"json": json.dumps({"tables": tables, "count": len(tables), "engine": "sqlite"})}
\t\telif action == "describe":
\t\t\ttable = data.get("table", "")
\t\t\tif not table:
\t\t\t\treturn {"json": json.dumps({"error": "No table specified"})}
\t\t\ttry:
\t\t\t\tquery = "SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, CHARACTER_MAXIMUM_LENGTH, ORDINAL_POSITION FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" + table.replace("'", "''") + "' ORDER BY ORDINAL_POSITION"
\t\t\t\tdataset = system.db.runQuery(query, database)
\t\t\t\tcolumns = []
\t\t\t\tfor row in range(dataset.getRowCount()):
\t\t\t\t\tcolumns.append({"name": str(dataset.getValueAt(row, 0)), "type": str(dataset.getValueAt(row, 1)), "nullable": str(dataset.getValueAt(row, 2)), "default": str(dataset.getValueAt(row, 3)) if dataset.getValueAt(row, 3) is not None else None, "maxLength": dataset.getValueAt(row, 4), "position": dataset.getValueAt(row, 5)})
\t\t\t\treturn {"json": json.dumps({"table": table, "columns": columns, "count": len(columns)})}
\t\t\texcept:
\t\t\t\tquery = "PRAGMA table_info('" + table.replace("'", "''") + "')"
\t\t\t\tdataset = system.db.runQuery(query, database)
\t\t\t\tcolumns = []
\t\t\t\tfor row in range(dataset.getRowCount()):
\t\t\t\t\tcolumns.append({"name": str(dataset.getValueAt(row, 1)), "type": str(dataset.getValueAt(row, 2)), "nullable": "NO" if dataset.getValueAt(row, 3) else "YES", "default": str(dataset.getValueAt(row, 4)) if dataset.getValueAt(row, 4) is not None else None, "maxLength": None, "position": dataset.getValueAt(row, 0)})
\t\t\t\treturn {"json": json.dumps({"table": table, "columns": columns, "count": len(columns), "engine": "sqlite"})}
\t\telse:
\t\t\treturn {"json": json.dumps({"error": "Unknown action: " + action + ". Use list_tables or describe."})}
\texcept:
\t\timport sys
\t\treturn {"json": json.dumps({"error": str(sys.exc_info()[1]), "traceback": traceback.format_exc()})}
