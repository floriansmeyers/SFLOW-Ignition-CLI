def doPost(request, session):
	import json
	try:
		body = request["data"]
		# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
		if isinstance(body, (str, unicode)):
			data = json.loads(body)
		elif isinstance(body, dict):
			data = body
		else:
			try:
				data = json.loads(system.util.jsonEncode(body))
			except Exception:
				return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
		path = data.get("path", "")
		project = data.get("project", "")
		params = data.get("params", {})
		if not path:
			return {"json": json.dumps({"error": "No query path provided"})}
		if project:
			dataset = system.db.runNamedQuery(project, path, params)
		else:
			dataset = system.db.runNamedQuery(path, params)
		if hasattr(dataset, "getColumnCount"):
			headers = [str(dataset.getColumnName(i)) for i in range(dataset.getColumnCount())]
			rows = []
			for row in range(dataset.getRowCount()):
				r = {}
				for col in range(dataset.getColumnCount()):
					val = dataset.getValueAt(row, col)
					r[headers[col]] = str(val) if val is not None else None
				rows.append(r)
			return {"json": json.dumps({"columns": headers, "rows": rows, "count": len(rows)})}
		else:
			return {"json": json.dumps({"result": str(dataset)})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
