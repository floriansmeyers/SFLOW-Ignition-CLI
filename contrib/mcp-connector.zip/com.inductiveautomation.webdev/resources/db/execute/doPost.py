def doPost(request, session):
\timport json
\timport traceback
\ttry:
\t\tbody = request["data"]
\t\t# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
\t\tif isinstance(body, (str, unicode)):
\t\t	data = json.loads(body)
\t\telif isinstance(body, dict):
\t\t	data = body
\t\telse:
\t\t	try:
\t\t		data = json.loads(system.util.jsonEncode(body))
\t\t	except Exception:
\t\t		return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
\t\tdatabase = data.get("database", "")
\t\tquery = data.get("query", "")
\t\tif not database:
\t\t\treturn {"json": json.dumps({"error": "No database specified"})}
\t\tif not query:
\t\t\treturn {"json": json.dumps({"error": "No query provided"})}
\t\tnormalized = query.strip().upper()
\t\twrite_prefixes = ("INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", "TRUNCATE", "EXEC", "EXECUTE", "MERGE", "REPLACE")
\t\tif normalized.startswith(write_prefixes):
\t\t\taffected = system.db.runUpdateQuery(query, database)
\t\t\treturn {"json": json.dumps({"affectedRows": affected})}
\t\tdataset = system.db.runQuery(query, database)
\t\theaders = [str(dataset.getColumnName(i)) for i in range(dataset.getColumnCount())]
\t\trows = []
\t\tfor row in range(min(dataset.getRowCount(), 1000)):
\t\t\tr = {}
\t\t\tfor col in range(dataset.getColumnCount()):
\t\t\t\tval = dataset.getValueAt(row, col)
\t\t\t\tif val is None:
\t\t\t\t\tr[headers[col]] = None
\t\t\t\telif hasattr(val, "getTime"):
\t\t\t\t\tr[headers[col]] = str(val)
\t\t\t\telse:
\t\t\t\t\tr[headers[col]] = val if isinstance(val, (bool, int, float, str)) else str(val)
\t\t\trows.append(r)
\t\treturn {"json": json.dumps({"columns": headers, "rows": rows, "rowCount": dataset.getRowCount(), "truncated": dataset.getRowCount() > 1000})}
\texcept:
\t\timport sys
\t\treturn {"json": json.dumps({"error": str(sys.exc_info()[1]), "traceback": traceback.format_exc()})}
