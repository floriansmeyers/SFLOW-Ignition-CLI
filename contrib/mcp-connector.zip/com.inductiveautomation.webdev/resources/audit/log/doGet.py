def doGet(request, session):
	import json
	from java.util import Date
	try:
		hours = int(request["params"].get("hours", "24"))
		limit = int(request["params"].get("limit", "100"))
		actor = request["params"].get("actor", "")
		profile = request["params"].get("profile", "")
		if not profile:
			# Auto-discover first available audit profile
			try:
				from com.inductiveautomation.ignition.gateway import IgnitionGateway
				gw = IgnitionGateway.get()
				mgr = gw.getAuditManager()
				profiles = list(mgr.getProfileNames())
				if profiles:
					profile = profiles[0]
				else:
					return {"json": json.dumps({"error": "No audit profiles configured on this gateway. Create one in Config > Security > Audit Profiles."})}
			except:
				# Java API not available; try common audit profile names
				for candidate in ["Audit", "default", "audit", "GatewayAudit"]:
					try:
						test = system.util.queryAuditLog(candidate, Date(), Date())
						profile = candidate
						break
					except:
						continue
				if not profile:
					return {"json": json.dumps({"error": "Could not auto-discover audit profile. Specify profile= parameter (tried: Audit, default, audit, GatewayAudit)."})}
		start = Date(Date().getTime() - (hours * 3600000))
		end = Date()
		dataset = system.util.queryAuditLog(profile, start, end)
		headers = [str(dataset.getColumnName(i)) for i in range(dataset.getColumnCount())]
		result = []
		for row in range(dataset.getRowCount()):
			if len(result) >= limit:
				break
			entry = {}
			for col in range(dataset.getColumnCount()):
				val = dataset.getValueAt(row, col)
				entry[headers[col]] = str(val) if val is not None else None
			if not actor or entry.get("ACTOR", entry.get("actor", "")) == actor:
				result.append(entry)
		return {"json": json.dumps({"events": result, "count": len(result), "columns": headers})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
