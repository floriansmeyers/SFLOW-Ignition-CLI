def doPost(request, session):
	import json
	try:
		body = request["data"]
		# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
		if isinstance(body, (str, unicode)):
			data = json.loads(body)
		elif isinstance(body, dict):
			data = body
		else:
			try:
				data = json.loads(system.util.jsonEncode(body))
			except Exception:
				return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
		action = data.get("action", "get")

		if action == "get":
			terms = data.get("terms", [])
			locale = data.get("locale", "")
			if not terms:
				return {"json": json.dumps({"error": "No terms provided. Pass a list of term keys."})}
			results = []
			for term in terms:
				if locale:
					translated = system.util.translate(term, locale, False)
				else:
					translated = system.util.translate(term)
				results.append({"term": term, "translation": str(translated)})
			return {"json": json.dumps({"translations": results, "count": len(results)})}

		elif action == "set":
			entries = data.get("entries", [])
			locale = data.get("locale", "")
			if not locale:
				return {"json": json.dumps({"error": "locale is required for set action (e.g. 'en', 'es', 'fr')"})}
			if not entries:
				return {"json": json.dumps({"error": "No entries provided. Pass a list of {term, translation} objects."})}
			# system.util.modifyTranslation silently does nothing in Gateway scope.
			# Use the Java API directly: TranslationPackageDiff + LocalizationManager.applyDiff()
			from com.inductiveautomation.ignition.gateway import IgnitionGateway
			from com.inductiveautomation.ignition.common.i18n.translation import TranslationPackageDiff
			from java.util import Locale as JavaLocale
			diff = TranslationPackageDiff()
			locale_obj = JavaLocale(locale)
			for entry in entries:
				term = entry.get("term", "")
				translation = entry.get("translation", "")
				if not term:
					return {"json": json.dumps({"error": "Each entry must have a non-empty term"})}
				diff.addTranslation(term, locale_obj, translation)
			IgnitionGateway.get().getLocalizationManager().applyDiff(diff)
			# Verify stored values (strict=True returns None if not found)
			results = []
			for entry in entries:
				term = entry.get("term", "")
				translation = entry.get("translation", "")
				stored = system.util.translate(term, locale, True)
				ok = stored is not None and str(stored) == translation
				results.append({"term": term, "translation": translation, "locale": locale, "verified": ok, "stored": str(stored) if stored else None})
			return {"json": json.dumps({"modified": results, "count": len(results)})}

		else:
			return {"json": json.dumps({"error": "Unknown action: " + action + ". Use get or set."})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
