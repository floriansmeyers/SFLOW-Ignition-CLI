def doPost(request, session):
	import json
	try:
		body = request["data"]
		# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
		if isinstance(body, (str, unicode)):
			data = json.loads(body)
		elif isinstance(body, dict):
			data = body
		else:
			try:
				data = json.loads(system.util.jsonEncode(body))
			except Exception:
				return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
		path = data.get("path", "")
		value = data.get("value")
		if not path:
			return {"json": json.dumps({"error": "No tag path provided"})}
		results = system.tag.writeBlocking([path], [value])
		return {"json": json.dumps({"path": path, "quality": str(results[0])})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
