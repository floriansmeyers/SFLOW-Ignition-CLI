def doGet(request, session):
	import json
	try:
		path = request["params"].get("path", "[default]")
		nameFilter = request["params"].get("filter", "")
		results = system.tag.browse(path)
		tags = []
		for node in results:
			# Handle both Java NodeDescription objects and dict-like results
			if hasattr(node, "getPath"):
				fullPath = str(node.getPath())
				name = str(node.getPath().getLastPathComponent()) if hasattr(node.getPath(), "getLastPathComponent") else fullPath.split("/")[-1]
			else:
				fullPath = str(node.get("fullPath", node.get("path", "")))
				name = str(node.get("name", fullPath.split("/")[-1]))
			if nameFilter and nameFilter.lower() not in name.lower():
				continue
			if hasattr(node, "getTagType"):
				tagType = str(node.getTagType())
			else:
				tagType = str(node.get("tagType", "Unknown"))
			if hasattr(node, "hasChildren"):
				children = node.hasChildren()
			else:
				children = bool(node.get("hasChildren", False))
			entry = {
				"fullPath": fullPath,
				"name": name,
				"tagType": tagType,
				"hasChildren": children,
			}
			if hasattr(node, "getDataType"):
				entry["dataType"] = str(node.getDataType())
			elif "dataType" in node if isinstance(node, dict) else hasattr(node, "dataType"):
				entry["dataType"] = str(node.get("dataType") if isinstance(node, dict) else node.dataType)
			# Read current value for leaf tags
			if tagType not in ("Folder", "Provider", "UdtType"):
				try:
					qv = system.tag.readBlocking([fullPath])[0]
					entry["value"] = str(qv.value)
					entry["quality"] = str(qv.quality)
				except:
					pass
			tags.append(entry)
		return {"json": json.dumps({"path": path, "tags": tags, "count": len(tags)})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
