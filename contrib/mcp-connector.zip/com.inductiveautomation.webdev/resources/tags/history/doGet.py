def doGet(request, session):
	import json
	from java.util import Date
	try:
		paths = request["params"].get("paths", "")
		tag_paths = [p.strip() for p in paths.split(",") if p.strip()]
		if not tag_paths:
			return {"json": json.dumps({"error": "No tag paths. Use ?paths=path1,path2"})}
		hours = int(request["params"].get("hours", "1"))
		maxResults = int(request["params"].get("maxResults", "500"))
		start = Date(Date().getTime() - (hours * 3600000))
		end = Date()
		dataset = system.tag.queryTagHistory(
			paths=tag_paths, startDate=start, endDate=end,
			returnSize=maxResults, aggregationMode="Average", returnFormat="Wide"
		)
		headers = [str(dataset.getColumnName(i)) for i in range(dataset.getColumnCount())]
		rows = []
		for row in range(dataset.getRowCount()):
			r = {}
			for col in range(dataset.getColumnCount()):
				val = dataset.getValueAt(row, col)
				r[headers[col]] = str(val) if val is not None else None
			rows.append(r)
		return {"json": json.dumps({"columns": headers, "rows": rows, "count": len(rows)})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
