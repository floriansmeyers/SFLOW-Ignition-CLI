def doGet(request, session):
	import json
	try:
		paths = request["params"].get("paths", "")
		tag_paths = [p.strip() for p in paths.split(",") if p.strip()]
		if not tag_paths:
			return {"json": json.dumps({"error": "No tag paths. Use ?paths=path1,path2"})}
		values = system.tag.readBlocking(tag_paths)
		result = []
		for i, qv in enumerate(values):
			result.append({
				"path": tag_paths[i],
				"value": str(qv.value),
				"quality": str(qv.quality),
				"timestamp": str(qv.timestamp),
			})
		return {"json": json.dumps({"tags": result, "count": len(result)})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
