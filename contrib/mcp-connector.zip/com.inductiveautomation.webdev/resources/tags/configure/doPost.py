def doPost(request, session):
\timport json
\ttry:
\t\tbody = request["data"]
\t\t# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
\t\tif isinstance(body, (str, unicode)):
\t\t	data = json.loads(body)
\t\telif isinstance(body, dict):
\t\t	data = body
\t\telse:
\t\t	try:
\t\t		data = json.loads(system.util.jsonEncode(body))
\t\t	except Exception:
\t\t		return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
\t\tprovider = data.get("provider", "default")
\t\ttags = data.get("tags", [])
\t\tcollision = data.get("collisionPolicy", "a")
\t\tif not tags:
\t\t\treturn {"json": json.dumps({"error": "No tags provided"})}
\t\tbase_path = data.get("basePath", "")
\t\tif base_path:
\t\t\tfull_path = "[" + provider + "]" + base_path
\t\telse:
\t\t\tfull_path = "[" + provider + "]"
\t\tresult = system.tag.configure(full_path, tags, collisionPolicy=collision)
\t\tquality_list = []
\t\tfor qv in result:
\t\t\tquality_list.append(str(qv))
\t\treturn {"json": json.dumps({"results": quality_list, "count": len(quality_list)})}
\texcept:
\t\timport sys
\t\treturn {"json": json.dumps({"error": str(sys.exc_info()[1])})}
