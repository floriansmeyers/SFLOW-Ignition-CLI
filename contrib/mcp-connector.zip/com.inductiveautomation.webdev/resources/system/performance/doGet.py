def doGet(request, session):
	import json
	try:
		from java.lang import Runtime
		from java.lang.management import ManagementFactory
		rt = Runtime.getRuntime()
		os_bean = ManagementFactory.getOperatingSystemMXBean()
		thread_bean = ManagementFactory.getThreadMXBean()
		runtime_bean = ManagementFactory.getRuntimeMXBean()
		total_mem = rt.totalMemory()
		free_mem = rt.freeMemory()
		max_mem = rt.maxMemory()
		result = {
			"jvm": {
				"heapUsedMB": round((total_mem - free_mem) / 1048576.0, 1),
				"heapTotalMB": round(total_mem / 1048576.0, 1),
				"heapMaxMB": round(max_mem / 1048576.0, 1),
				"heapUsagePercent": round((total_mem - free_mem) * 100.0 / max_mem, 1),
			},
			"cpu": {
				"availableProcessors": os_bean.getAvailableProcessors(),
				"systemLoadAverage": os_bean.getSystemLoadAverage(),
			},
			"threads": {
				"threadCount": thread_bean.getThreadCount(),
				"peakThreadCount": thread_bean.getPeakThreadCount(),
				"daemonThreadCount": thread_bean.getDaemonThreadCount(),
			},
			"uptime": {
				"uptimeMs": runtime_bean.getUptime(),
				"uptimeHours": round(runtime_bean.getUptime() / 3600000.0, 2),
				"startTime": str(runtime_bean.getStartTime()),
			},
		}
		return {"json": json.dumps(result)}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
