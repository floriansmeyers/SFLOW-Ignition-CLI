def doGet(request, session):
	import json
	try:
		username = request["params"].get("username", "")
		project = request["params"].get("project", "")
		if username and project:
			sessions = system.perspective.getSessionInfo(username, project)
		elif username:
			sessions = system.perspective.getSessionInfo(username)
		else:
			sessions = system.perspective.getSessionInfo()
		result = []
		for s in sessions:
			entry = {
				"id": str(s.getId()) if hasattr(s, "getId") else str(s),
				"project": str(s.getProjectName()) if hasattr(s, "getProjectName") else "",
				"username": str(s.getUsername()) if hasattr(s, "getUsername") else "",
				"userAgent": str(s.getUserAgent()) if hasattr(s, "getUserAgent") else "",
			}
			if hasattr(s, "getPageIds"):
				try:
					entry["pageCount"] = len(list(s.getPageIds()))
				except:
					pass
			result.append(entry)
		return {"json": json.dumps({"sessions": result, "count": len(result)})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
