def doPost(request, session):
	import json
	try:
		body = request["data"]
		sources = []
		if body:
			# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
			if isinstance(body, (str, unicode)):
				data = json.loads(body)
			elif isinstance(body, dict):
				data = body
			else:
				try:
					data = json.loads(system.util.jsonEncode(body))
				except Exception:
					return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
			sources = data.get("sources", [])
		alarms = system.alarm.queryStatus()
		to_ack = []
		for event in alarms:
			stateStr = str(event.getState()).lower()
			if "unacknowledged" in stateStr:
				if not sources or str(event.getSource()) in sources:
					to_ack.append(event)
		count = len(to_ack)
		if to_ack:
			system.alarm.acknowledge(to_ack, "Acknowledged via MCP")
		return {"json": json.dumps({"acknowledged": count})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
