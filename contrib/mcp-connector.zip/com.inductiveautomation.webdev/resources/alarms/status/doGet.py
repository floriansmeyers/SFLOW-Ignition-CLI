def doGet(request, session):
	import json
	try:
		kwargs = {}
		src = request["params"].get("source", "")
		pri = request["params"].get("priority", "")
		if src:
			kwargs["source"] = [src]
		# Note: minPriority kwarg is unreliable in Gateway scope on some 8.x versions,
		# so we post-filter by priority level instead.
		alarms = system.alarm.queryStatus(**kwargs)
		PRIORITY_ORDER = {"Diagnostic": 0, "Low": 1, "Medium": 2, "High": 3, "Critical": 4}
		min_level = PRIORITY_ORDER.get(pri, 0) if pri else 0
		result = []
		for event in alarms:
			alarm_pri = str(event.getPriority())
			if pri and PRIORITY_ORDER.get(alarm_pri, 0) < min_level:
				continue
			stateStr = str(event.getState())
			entry = {
				"source": str(event.getSource()),
				"displayPath": str(event.getDisplayPath()),
				"name": str(event.getName()),
				"priority": alarm_pri,
				"state": stateStr,
			}
			# Parse active/acked/clear from state string
			# Ignition 8.3 uses "Active, Unacknowledged" / "Cleared, Acknowledged" etc.
			sl = stateStr.lower()
			entry["isActive"] = "active" in sl and "inactive" not in sl
			entry["isAcked"] = "acknowledged" in sl and "unacknowledged" not in sl
			entry["isClear"] = "clear" in sl
			result.append(entry)
		# Sort: active first, then cleared-unacked, then cleared-acked
		def sort_key(a):
			if a["isActive"]:
				return 0
			if a["isClear"] and not a["isAcked"]:
				return 1
			return 2
		result.sort(key=sort_key)
		return {"json": json.dumps({"alarms": result, "count": len(result)})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
