def doGet(request, session):
	import json
	from java.util import Date
	try:
		hours = int(request["params"].get("hours", "24"))
		limit = int(request["params"].get("limit", "100"))
		journalName = request["params"].get("journalName", "")
		start = Date(Date().getTime() - (hours * 3600000))
		end = Date()
		# system.alarm.queryJournal may be None in Gateway scope on some 8.x versions
		qjFn = getattr(system.alarm, "queryJournal", None)
		if qjFn is None:
			return {"json": json.dumps({"error": "system.alarm.queryJournal is not available in Gateway scope on this version. Use execute_sql_query() to query alarm journal tables directly, or use get_alarm_journal_profile() to find the database name."})}
		try:
			if journalName:
				events = qjFn(journalName=journalName, startDate=start, endDate=end)
			else:
				events = qjFn(startDate=start, endDate=end)
		except Exception, e1:
			# Retry with positional args (some versions need this)
			try:
				if journalName:
					events = qjFn(start, end, journalName)
				else:
					events = qjFn(start, end)
			except Exception, e2:
				return {"json": json.dumps({"error": "queryJournal failed: " + str(e1) + " | positional retry: " + str(e2) + ". Use execute_sql_query() against the journal database instead."})}
		result = []
		for i, event in enumerate(events):
			if i >= limit:
				break
			# PyAlarmEvent uses bracket access for eventTime (not a method);
			# getSource/getDisplayPath/getName/getPriority/getState are real methods.
			# Use .get() with fallback for safety on all fields.
			try:
				evt_time = str(event["eventTime"])
			except Exception:
				try:
					ad = event.getActiveData()
					evt_time = str(ad) if ad else ""
				except Exception:
					evt_time = ""
			result.append({
				"source": str(event.getSource()) if event.getSource() is not None else "",
				"displayPath": str(event.getDisplayPath()) if event.getDisplayPath() is not None else "",
				"name": str(event.getName()) if event.getName() is not None else "",
				"priority": str(event.getPriority()) if event.getPriority() is not None else "",
				"state": str(event.getState()) if event.getState() is not None else "",
				"eventTime": evt_time,
			})
		return {"json": json.dumps({"events": result, "count": len(result)})}
	except:
		import sys
		return {"json": json.dumps({"error": str(sys.exc_info()[1])})}
