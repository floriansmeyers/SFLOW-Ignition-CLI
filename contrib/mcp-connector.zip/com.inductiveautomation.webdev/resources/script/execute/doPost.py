def doPost(request, session):
\timport json
\timport sys
\timport traceback
\ttry:
\t\tbody = request["data"]
\t\t# WebDev auto-parses JSON bodies — may be a Python dict, Java Map, or raw string
\t\tif isinstance(body, (str, unicode)):
\t\t	data = json.loads(body)
\t\telif isinstance(body, dict):
\t\t	data = body
\t\telse:
\t\t	try:
\t\t		data = json.loads(system.util.jsonEncode(body))
\t\t	except Exception:
\t\t		return {"json": json.dumps({"error": "Failed to parse request body (type=%s, len=%d)" % (type(body).__name__, len(str(body)))})}
\t\tfunc_name = data.get("function", "")
\t\targs = data.get("args", [])
\t\tkwargs = data.get("kwargs", {})
\t\tif not func_name:
\t\t\treturn {"json": json.dumps({"error": "No function name provided"})}
\t\tif not func_name.startswith("system."):
\t\t\treturn {"json": json.dumps({"error": "Only system.* functions are allowed"})}
\t\tparts = func_name.split(".")
\t\tobj = sys.modules.get("system")
\t\tif obj is None:
\t\t\timport system
\t\t\tobj = system
\t\tfor part in parts[1:]:
\t\t\tobj = getattr(obj, part)
\t\tresult = obj(*args, **kwargs)
\t\treturn {"json": json.dumps({"result": _serialize(result)})}
\texcept:
\t\timport sys
\t\treturn {"json": json.dumps({"error": str(sys.exc_info()[1]), "traceback": traceback.format_exc()})}

def _serialize(obj):
\tif hasattr(obj, "getColumnCount") and hasattr(obj, "getRowCount"):
\t\theaders = [str(obj.getColumnName(i)) for i in range(obj.getColumnCount())]
\t\trows = []
\t\tfor row in range(min(obj.getRowCount(), 1000)):
\t\t\tr = {}
\t\t\tfor col in range(obj.getColumnCount()):
\t\t\t\tval = obj.getValueAt(row, col)
\t\t\t\tr[headers[col]] = _serialize_value(val)
\t\t\trows.append(r)
\t\treturn {"_type": "dataset", "columns": headers, "rows": rows, "rowCount": obj.getRowCount()}
\tif hasattr(obj, "quality") and hasattr(obj, "timestamp"):
\t\treturn {"_type": "qualifiedValue", "value": _serialize_value(getattr(obj, "value", None)), "quality": str(obj.quality), "timestamp": str(obj.timestamp)}
\tif isinstance(obj, (list, tuple)):
\t\treturn [_serialize(item) for item in obj]
\tif hasattr(obj, "__iter__") and not isinstance(obj, (str, dict)):
\t\ttry:
\t\t\treturn [_serialize(item) for item in obj]
\t\texcept:
\t\t\tpass
\tif hasattr(obj, "getPath") and hasattr(obj, "getTagType"):
\t\treturn {"_type": "browseTag", "path": str(obj.getPath()), "tagType": str(obj.getTagType()), "dataType": str(obj.getDataType()) if hasattr(obj, "getDataType") else None}
\treturn _serialize_value(obj)

def _serialize_value(val):
\tif val is None:
\t\treturn None
\tif isinstance(val, (bool, int, float, str)):
\t\treturn val
\tif hasattr(val, "getTime"):
\t\treturn str(val)
\ttry:
\t\treturn str(val)
\texcept:
\t\treturn repr(val)
